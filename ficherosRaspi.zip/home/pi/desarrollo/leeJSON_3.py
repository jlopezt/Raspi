import json

data={"Temperatura": 23.9,"Humedad": 37.3,"Luz": 1.0,"id": 0}

#Nos imprime en pantalla data como un tipo de dato nativo.
#print 'DATA:', repr(data)

#Nos devuelve el String con el JSON
data_string = json.dumps(data)
#print 'JSON:', data_string

decoded = json.loads(data_string)
print 'DECODED:', decoded

print 'id= ' + str(decoded["id"])
print 'Temperatura= ' + str(decoded["Temperatura"]) + " C"
print "Humedad= " + str(decoded["Humedad"]) + " %"
print "Luz= " + str(decoded["Luz"])


