print ("Hello world")
