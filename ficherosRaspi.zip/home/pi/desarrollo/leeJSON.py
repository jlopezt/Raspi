import json

#data = {"Fruteria": [  {"Fruta":   [    {"Nombre":"Manzana","Cantidad":10},    {"Nombre":"Pera","Cantidad":20},    {"Nombre":"Naranja","Cantidad":30}   ]  },  {"Verdura":   [    {"Nombre":"Lechuga","Cantidad":80},    {"Nombre":"Tomate","Cantidad":15},    {"Nombre":"Pepino","Cantidad":50}   ]  } ]}
#data = {"medida":23.1,"consigna":23,"modo":2,"tics":720,"habitaciones":[{"id":0,"nombre":"Salon","temperatura":22.6,"humedad":34.2,"luz":2},{"id":4,"nombre":"Sara","temperatura":24.1,"humedad":35.5,"luz":10},{"id":6,"nombre":"Buhardilla","temperatura":22.6,"humedad":35.9,"luz":6},{"id":7,"nombre":"Bodega","temperatura":18.9,"humedad":34.6,"luz":0}],"reles":[{"id":0,"nombre":"Calefaccion","estado":0},{"id":1,"nombre":"Otros","estado":1}]}
data={"medida":23.1125,"consigna":23,"modo":2,"tics":720,"habitaciones":[{"id":0,"nombre":"Salon","temperatura":22.8,"humedad":27.7,"luz":6},{"id":3,"nombre":"Jorge","temperatura":24.1,"humedad":34.6,"luz":33},{"id":4,"nombre":"Sara","temperatura":23.1,"humedad":29.4,"luz":8},{"id":6,"nombre":"Buhardilla","temperatura":21.8,"humedad":33.6,"luz":5},{"id":7,"nombre":"Bodega","temperatura":19.6,"humedad":29.8,"luz":0},{"id":9,"nombre":"Exterior","temperatura":11.3,"humedad":51.3,"luz":83}],"reles":[{"id":0,"nombre":"Calefaccion","estado":0},{"id":1,"nombre":"Otros","estado":1}]}

#Nos imprime en pantalla data como un tipo de dato nativo.
#print 'DATA:', repr(data)

#Nos devuelve el String con el JSON
data_string = json.dumps(data)
#print 'JSON:', data_string

decoded = json.loads(data_string)
#print 'DECODED:', decoded

#print "Tenemos " + str(decoded["Fruteria"][1]["Verdura"][0]["Cantidad"]) + " Lechugas."
print 'Temperatura= ' + str(decoded["medida"]) + " C"
print "Consigna= " + str(decoded["consigna"]) + " C"
if (decoded["modo"]==2): print "Modo auto"

