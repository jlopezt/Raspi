import time
import os

import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish

# Informacion sobre el bus MQTT
Broker = "10.68.1.100"
sub_topic = "casa/+/medidas"    # receive messages on this topic
pub_topic = "casa/monitor"      # send messages to this topic

#ficheros
directorioSalida="/logs/"
nombreSalida="MQTT.log"

#inicializamos el fichero
currentDir=os.getcwd()+directorioSalida
if not(os.path.exists(currentDir)):
     os.mkdir(currentDir)
     
fichero=currentDir + nombreSalida
print("nombre del fichero de log: "+fichero)
#salida=open(fichero,'at',encoding = 'utf-8')

# mqtt section

# when connecting to mqtt do this;

def on_connect(client, userdata, flags, rc):
    print("Conectado con el codigo de resultado "+str(rc))
    client.subscribe(sub_topic)
    publish_mqtt("Conectrado al bus...")

# when receiving a mqtt message do this;

def on_message(client, userdata, msg):
    message = str(msg.payload)
    print(msg.topic+" "+message)
    publish_mqtt("Mensaje leido.")
    with open(fichero,'a',encoding = 'utf-8') as f:
        f.write(msg.topic+">"+message+"\n")

# to send a message

def publish_mqtt(sensor_data):
    mqttc = mqtt.Client("monitor_Raspi")
    mqttc.connect(Broker, 1883)
    mqttc.publish(pub_topic, sensor_data)
    #mqttc.loop(2) //timeout = 2s

def on_publish(mosq, obj, mid):
    print("mid: " + str(mid))


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.connect(Broker, 1883, 60)
client.loop_forever()
